'use strict';

var path = require('path');
var util = require('util');
var parseArgs = require('minimist');
var printf = require('printf');
var _ = require('underscore');
var operations = require(path.join(__dirname, 'lib', 'operations.js'));

var config = require(path.join(__dirname, 'lib', 'config.js'));
var alias = require(path.join(__dirname, 'lib', 'alias.js'));

var CONSTANTS = require(path.join(__dirname, 'lib', 'constants.js'));

var log = require(path.join(__dirname, 'lib', 'logger.js')).getLogger('npi');

var args = process.argv;

function printUsage() {
  var formatStr = "  %-15s %s";

  console.log("New Relic Platform Installer is a command line utility for easily downloading, configuring and running plugins.")
  console.log();
  console.log("Usage: ");
  console.log("  npi <command>");
  console.log();
  console.log("Most popular commands: ");
  console.log(printf(formatStr, "add-service", "Set up a plugin to run in the background"));
  console.log(printf(formatStr, "alias", "Set up an alias for a plugin guid"));
  console.log(printf(formatStr, "available", "Displays a list of available plugins"));
  console.log(printf(formatStr, "config", "Configure the npi tool"));
  console.log(printf(formatStr, "fetch", "Download a plugin to the filesystem"));
  console.log(printf(formatStr, "install", "Interactive setup of a new plugin"));
  console.log(printf(formatStr, "list", "Display information about plugins on the filesystem"));
  console.log(printf(formatStr, "prepare", "Prepare a plugin to run by setting up its config files"));
  console.log(printf(formatStr, "remove", "Remove a plugin from the filesystem"));
  console.log(printf(formatStr, "remove-service", "Remove a plugin as a background process"));
  console.log(printf(formatStr, "start", "Start a plugin process (both foreground and background supported)"));
  console.log(printf(formatStr, "stop", "Stop a plugin's background process from running"));
  console.log(printf(formatStr, "where", "Displays the location of this plugin on the filesystem"));
  console.log();
  console.log("Flags: ");
  console.log("  -h, --help     Print this help information");
  console.log("  -v, --version  Print the current npi tool's version");
  console.log();
  console.log("Example flows: ");
  console.log("  Interactive: ");
  console.log("    npi install <plugin>");
  console.log();
  console.log("  Manual: ");
  console.log("    npi config set license_key <YOUR_LICENSE_KEY>");
  console.log("    npi fetch <plugin>");
  console.log("    npi prepare <plugin>");
  console.log("    npi start <plugin> --foreground");
  console.log("    npi add-service <plugin> --start");
  console.log();
  console.log("Additional help: ");
  console.log("  npi <command> --help or -h")
}

function printQuickHelp(key) {
  var noShorthandFormatStr = "      %-20s %s";
  var shorthandFormatStr = "% 4s, %-20s %s";

  switch (key) {
    case 'add-service':
      console.log("Sets up a plugin to run as a background service (Currently only supports Linux and Windows).");
      console.log();
      console.log("Usage: ");
      console.log("  npi add-service <plugin> <flags>");
      console.log();
      console.log("Flags: ");
      console.log(printf(noShorthandFormatStr, "--distro=<distro>", "* Linux only * Set distribution family of your computer. [debian or redhat]"));
      console.log(printf(shorthandFormatStr, "-q", "--quiet", "Limit console output"));
      console.log(printf(shorthandFormatStr, "-s", "--start", "Start the plugin service in the background after the operation is complete"));
      console.log(printf(noShorthandFormatStr, "--user=<user>", "* Linux only * Required field to set the plugin service to run as this user")); 
      break;
    case 'alias':
      console.log("Allows creation of aliases that can be used in place of plugin guids");
      console.log();
      console.log("Usage: ");
      console.log("  npi alias get <alias>");
      console.log("  npi alias set <alias> <plugin>");
      console.log("  npi alias delete <alias>");
      console.log("  npi alias list");
      break;
    case 'available':
      console.log("Displays a list of available plugins.");
      console.log();
      console.log("Usage: ");
      console.log("  npi available");
      break;
    case 'config':
      var configFormatStr = "  %-15s %s";

      console.log("Allows configuration of this tool (note options marked with '*' will be copied to downloaded plugins)");
      console.log("If you update any asterisked fields, run 'npi prepare <plugin> -q' to copy changes to a plugin");
      console.log();
      console.log("Usage: ");
      console.log("  npi config get <key>");
      console.log("  npi config set <key> <value>");
      console.log("  npi config delete <key>");
      console.log("  npi config list");
      console.log();
      console.log("Options: ");
      console.log(printf(configFormatStr, "Key", "Description"));
      console.log(printf(configFormatStr, "distro", "* Linux Only * Set your Linux family [debian or redhat]"))
      console.log(printf(configFormatStr, "*license_key", "Your New Relic license key"));
      console.log(printf(configFormatStr, "log_level", "[ debug, info, warn, error, fatal ] Defaults to 'info'"));
      console.log(printf(configFormatStr, "log_to_file", "[ true, false ] Defaults to 'false'"));
      console.log(printf(configFormatStr, "*proxy_host", "Your proxy host"));
      console.log(printf(configFormatStr, "*proxy_port", "Your proxy port"));
      console.log(printf(configFormatStr, "*proxy_username", "Your proxy user"));
      console.log(printf(configFormatStr, "*proxy_password", "Your proxy pass"));
      break;
    case 'fetch':
      console.log("Downloads the plugin and extracts it locally.");
      console.log();
      console.log("Usage: ");
      console.log("  npi fetch <plugin> <flags>");
      console.log();
      console.log("Flags: ");
      console.log(printf(shorthandFormatStr, "-q", "--quiet", "Limit console output"));
      console.log(printf(shorthandFormatStr, "-u", "--untrusted", "Allow use of local 'manifest.json' file"));
      console.log(printf(shorthandFormatStr, "-y", "--yes", "Auto-accept all prompts"));
      break;
    case 'install':
      console.log("Walks you through the process of setting up a plugin for the first time");
      console.log();
      console.log("Usage: ");
      console.log("  npi install <plugin> <flags>");
      console.log();
      console.log("Flags: ");
      console.log(printf(noShorthandFormatStr, "--distro=<distro>", "* Linux only * Set distribution family of your computer. [debian or redhat]"));
      console.log(printf(shorthandFormatStr, "-n", "--noedit", "Do not open 'plugin.json' in an editor"));
      console.log(printf(shorthandFormatStr, "-s", "--start", "Start the plugin service in the background after the operation is complete"));
      console.log(printf(shorthandFormatStr, "-q", "--quiet", "Limit console output"));
      console.log(printf(shorthandFormatStr, "-u", "--untrusted", "Allow use of local 'manifest.json' file"));
      console.log(printf(noShorthandFormatStr, "--user=<user>", "* Linux only * Required field to set the plugin service to run as this user")); 
      console.log(printf(shorthandFormatStr, "-y", "--yes", "Auto-accept all prompts"));
      break;
    case 'list':
      console.log("Lists information about the plugins currently installed on this system");
      console.log();
      console.log("Usage: ");
      console.log("  npi list");
      console.log("  npi list <plugin>");
      console.log();
      console.log("Flags: ");
      console.log(printf(shorthandFormatStr, "-v", "--verbose", "View verbose information about a plugin"));
      break;
    case 'prepare':
      console.log("Prepares the plugin to run and opens its 'plugin.json' in a text editor");
      console.log("  Default editor on Unix is 'vi'");
      console.log("  Default editor on Windows is 'notepad'");
      console.log("  Change the default editor by setting an environment variable named $EDITOR");
      console.log();
      console.log("Usage: ");
      console.log("  npi prepare <plugin> <flags>");
      console.log();
      console.log("Flags: ");
      console.log(printf(shorthandFormatStr, "-n", "--noedit", "Do not open 'plugin.json' in an editor"));
      console.log(printf(shorthandFormatStr, "-o", "--override", "Override any existing 'plugin.json' configuration"));
      console.log(printf(shorthandFormatStr, "-q", "--quiet", "Limit console output"));
      break;
    case 'remove':
      console.log("Completely removes the plugin locally.");
      console.log();
      console.log("Usage: ");
      console.log("  npi remove <plugin> <flags>");
      console.log();
      console.log("Flags: ");
      console.log(printf(shorthandFormatStr, "-a", "--all",  "Delete ALL plugins currently downloaded"));
      console.log(printf(shorthandFormatStr, "-y", "--yes", "Auto-accept all prompts"));
      break;
    case 'remove-service':
      console.log("Removes the plugin as a background process but keeps it on the box.");
      console.log();
      console.log("Usage: ");
      console.log("  npi remove-service <plugin>");
      break;
    case 'start':
      console.log("Starts the plugin either in the foreground or background based on flags.");
      console.log();
      console.log("Usage: ");
      console.log("  npi start <plugin> <flags>");
      console.log();
      console.log("Flags: ");
      console.log(printf(shorthandFormatStr, "-f", "--foreground", "Starts the plugin in the foreground"));
      break;
    case 'stop':
      console.log("Stops a plugin running in the background.");
      console.log();
      console.log("Usage: ");
      console.log("  npi stop <plugin>");
      break;
    case 'where':
      console.log("Displays the full path to a plugin on the filesystem.");
      console.log();
      console.log("Usage: ");
      console.log("  npi where <plugin>");
      break;
    default:
      printUsage();
  }

  console.log();
}

// Set up global handler to ensure we log all uncaught errors
process.on('uncaughtException', function(err) {
  log.debug(util.inspect(err));

  // Handle known errors with a cleaner message
  if (err.code && err.code === 'EACCES') {
    log.error("Insufficient privileges, please re-run the command elevated.");
  } else {
    log.error(err.message);
    log.error(err.stack);
  }

  process.exit(1);
});

var cmd = args[2];

// Check to see if they've requested '-v' to view the version of the tool
if (cmd === '-v' || cmd === '--version') {
  console.log('v' + CONSTANTS.VERSION);
  return 0;
}

// Check to see if they've requested '-h' to view the help for an action
if (args[3] === '-h' || args[3] === '--help') {
  printQuickHelp(cmd);
  return 0;
}

// Set up flag aliases
var opts = {};
opts.alias = {};

opts.alias['yes'] = ['y'];
opts.alias['untrusted'] = ['u'];
opts.alias['all'] = ['a'];
opts.alias['foreground'] = ['f'];
opts.alias['quiet'] = ['q'];
opts.alias['start'] = ['s'];
opts.alias['distro'] = ['d'];
opts.alias['override'] = ['o'];
opts.alias['noedit'] = ['n'];
opts.alias['verbose'] = ['v'];

function handleErr(err, message) {
  if (err) {
    log.error(util.inspect(err));
    process.exit(1);
  }
}

var parsedArgs = parseArgs(args.slice(3), opts);

var params = parsedArgs._;
var flags = parsedArgs;

log.debug("Params: " + JSON.stringify(params));
log.debug("Flags: " + JSON.stringify(flags));

// if plugin name is an alias, replace it with the guid
function isAliasable(cmd) {
  return _.contains([
    'fetch',
    'remove',
    'start',
    'stop',
    'add-service',
    'remove-service',
    'upgrade',
    'prepare',
    'install',
    'where'
  ], cmd);
}

if (isAliasable(cmd) && alias.resolveAlias(params[0]) !== null) {
  params[0] = alias.resolveAlias(params[0]);
}

switch (cmd) {
  case 'available':
    operations.available(params, flags, handleErr); break;
  case 'fetch':
    operations.fetch(params, flags, handleErr); break;
  case 'remove':
    operations.remove(params, flags, handleErr); break;
  case 'start':
    operations.start(params, flags, handleErr); break;
  case 'stop':
    operations.stop(params, flags, handleErr); break;
  case 'add-service':
    operations.addService(params, flags, handleErr); break;
  case 'remove-service': 
    operations.removeService(params, flags, handleErr); break;
  case 'upgrade':
    operations.upgrade(params, flags, handleErr); break;
  case 'config':
    operations.config(args.slice(3), handleErr); break; // Pass raw params because minimist will parse nested flags
  case 'get':
  case 'set':
    operations.config(args.slice(2), handleErr); break;
  case 'prepare':
    operations.prepare(params, flags, handleErr); break;
  case 'list':
    operations.list(params, flags, handleErr); break;
  case 'alias':
    operations.alias(params, flags , handleErr); break;
  case 'install':
    operations.install(params, flags, args.slice(3), handleErr); break; // Send the raw args since they will need to be propagated to a subprocess
  case 'where':
    operations.where(params, flags, handleErr); break;

  default:
    printUsage();
}
